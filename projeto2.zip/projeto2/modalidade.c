#include "estruturas.h"
#include "modalidade.h"
#include "atleta.h"
#include "equipe.h"

void cadastroMod(struct modalidade *modalidades, int *contmod)
{
  if(*contmod > 10){
    printf("Limite de modalidades atingidos");
    return;
  }

  struct modalidade novamodalidade;
  
  printf("\nmodalidade: ");
  fgets(novamodalidade.mod, 50, stdin);
  
  printf("Quantidades de atletas por equipes: ");
  scanf("%d", &novamodalidade.quantAtleta);
  
  modalidades[*contmod] = novamodalidade;
  (*contmod)++; 

  printf("\nModalidade cadastrada com sucesso\n");
  printf("\nDados da modalidade.\n");
  for (int i = 0; i < *contmod; i++){
    printf("modalidade: %s", modalidades[i].mod);
    printf("Quantidades de atletas na equipe: %d\n", modalidades[i].quantAtleta);
  }
}

void excluirMod(struct modalidade *modalidades, int *contmod, struct equipe *equipes, int *contequ) {

  char mod[50];
  int indice = -1;

   printf("\nDigite o nome da modalidade: ");
   fgets(mod, 50, stdin);
 
  for(int i = 0; i < *contmod; i++){
    if(strcmp(modalidades[i].mod, mod) == 0){
      indice = i;
      break;
    }
  }

  if(indice == -1){
    printf("Modalidade %s nao encontrada\n", mod);
  } else {
    for(int i = 0; i < *contequ; i++){
      for(int j = 0; j < equipes[i].quantMod; j++){
        if(strcmp(equipes[i].listaMod[j].mod, mod) == 0){
          for(int k = j; k < equipes[i].quantMod - 1; k++){
            equipes[i].listaMod[k] = equipes[i].listaMod[k + 1];
          }
          equipes[i].quantMod--;
          break;
        }
      }
    }

    for(int i = indice; i < *contmod - 1; i++){
      modalidades[i] = modalidades[i + 1];
    }

    (*contmod)--;
    printf("Modalidade %s excluida com sucesso.\n", mod);
  }  
}

void atualizarMod(struct modalidade *modalidades, int *contmod, struct equipe *equipes, int *contequ) {

  char mod[50];
  printf("\nDigite o nome da modalidade que deseja atualizar: ");
  fgets(mod, 50, stdin);

  int indice = -1;
  for(int i = 0; i < *contmod; i++){
    if(strcmp(modalidades[i].mod, mod) == 0){
      indice = i;
      break;
    }
  }

  if(indice == -1){
    printf("Modalidade %s nao encontrada\n", mod);
    return;
  }

  int opcao;
  printf("\nEscolha a opcao que deseja atualizar:\n");
  printf("1. Alterar todos os dados\n");
  printf("2. Alterar nome\n");
  printf("3. Alterar quantidade de atletas\n");
  printf("4. Cancelar\n");
  printf("Escolha a opcao desejada: ");
  scanf("%d", &opcao);
  getchar();

  switch(opcao){
    case 1:
      printf("Novo nome da modalidade: ");
      fgets(modalidades[indice].mod, 50, stdin);
      for(int i = 0; i < *contequ; i++){
        for(int j = 0; j < equipes[i].quantMod; j++){
          if(strcmp(equipes[i].listaMod[j].mod, mod)== 0){
            strcpy(equipes[i].listaMod[j].mod, modalidades[indice].mod);
          }
        }
      }
      printf("Nova quantidade de atletas por equipe: ");
      scanf("%d", &modalidades[indice].quantAtleta);
      for(int i = 0; i < *contequ; i++){
        for(int j = 0; j < equipes[i].quantMod; j++){
          if(strcmp(equipes[i].listaMod[j].mod, mod)== 0){
             (equipes[i].listaMod[j].quantAtleta = modalidades[indice].quantAtleta);
          }
        }
      }
      printf("Dados da modalidade atualizados com sucesso\n");
      break;

    case 2:
      printf("Novo nome da modalidade: ");
      fgets(modalidades[indice].mod, 50, stdin);
      for(int i = 0; i < *contequ; i++){
        for(int j = 0; j < equipes[i].quantMod; j++){
          if(strcmp(equipes[i].listaMod[j].mod, mod)== 0){
            strcpy(equipes[i].listaMod[j].mod, modalidades[indice].mod);
          }
        }
      }
      printf("nome da modalidade atualizados com sucesso\n");
      break;
    case 3:
      printf("Nova quantidade de atletas por equipe: ");
      scanf("%d", &modalidades[indice].quantAtleta);
      for(int i = 0; i < *contequ; i++){
        for(int j = 0; j < equipes[i].quantMod; j++){
          if(strcmp(equipes[i].listaMod[j].mod, mod)== 0){
            (equipes[i].listaMod[j].quantAtleta = modalidades[indice].quantAtleta);
          }
        }
      }
      printf("Quantidade de atletas da modalidade atualizados com sucesso\n");
      break;

    case 4:
      printf("Operação cancelada\n");
      break;
      default:
      printf("Opção inválida\n");

      *contmod ++;
    } 
}

void registromod(struct modalidade *modalidades, int *contmod){
  
  if (*contmod == 0) {
      printf("SEM REGISTRO\n");
      return; 
    }
    
  char mod[50];
  printf("\nDigite o nome da modalidade que deseja acessar: ");
  fgets(mod, 50, stdin);

  int indice = -1;
  for (int i = 0; i < *contmod; i++) {
    if (strcmp(modalidades[i].mod, mod) == 0) {
      indice = i;
      break;
      }
    }

    if (indice == -1) {
      printf("Modalidade %s não encontrada\n", mod);
    } else {
      printf("\nDetalhes da modalidade: %s\n", mod);
      printf("Nome: %s", modalidades[indice].mod);
      printf("Quantidade de atletas por equipe: %d\n", modalidades[indice].quantAtleta);
    }
}

void registrogeralMOD(struct modalidade *modalidades, int *contmod) {

   printf("\nRegistros de todas as modalidades.\n");
   for (int i = 0; i < *contmod; i++) {
    printf("\nModalidade %d:\n", i + 1);
    printf("Nome: %s", modalidades[i].mod);
    printf("Quantidade de atletas por equipe: %d\n", modalidades[i].quantAtleta);
  }
}

void submenuMod(struct modalidade *modalidades, int *contmod, struct equipe *equipes, int *contequ){
  
  int escolha;

  do {
    printf("\nMenu modalidade:\n");
    printf("1. Cadastar\n");
    printf("2. Excluir\n");
    printf("3. Atualizar\n");
    printf("4. Exibir registro\n");
    printf("5. Exibir todos os registros\n");
    printf("6. Sair do sistema\n");
    printf("\n");

    printf("Escolha a opcao desejada: ");
    scanf("%d", &escolha);
    getchar();
    
    switch(escolha) {

      case 1:
        cadastroMod(modalidades, &*contmod);
        break;
      
      case 2:
        excluirMod(modalidades, &*contmod, equipes, &*contequ);
        break;
      
      case 3:
        atualizarMod(modalidades, &*contmod, equipes, &*contequ);
        break;

      case 4:
        registromod(modalidades, &*contmod);
        break;
      
      case 5:
        registrogeralMOD(modalidades, &*contmod);
        break;
        default:
        printf("Opcao invalida, tente novamente\n");
    }

  } while(escolha != 6);

} 

  