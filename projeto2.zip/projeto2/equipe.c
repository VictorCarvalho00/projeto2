#include "estruturas.h"
#include "equipe.h"
#include "atleta.h"
#include "modalidade.h"
#include "torneio.h"
#include "jogo.h"

void cadastroEquipe(struct equipe *equipes, int *contequ, struct atleta *atletas, int *conAtl, struct modalidade *modalidades, int *contmod){
  if(*contequ > 100){
    printf("Limite de equipes atingido");
    return;
  }

  struct equipe novaequipe;
  novaequipe.quantAtleta = 0;
  novaequipe.quantMod = 0;

  printf("\nNome da equipe: ");
  fgets(novaequipe.nome, 50, stdin);

  printf("Sigla da equipe: ");
  fgets(novaequipe.sigla, 5, stdin);

  printf("Modalidades disponiveis:\n");
  for(int i = 0; i < *contmod; i++){
    printf("%d. %s\n", i + 1, modalidades[i].mod);
  }

  int escolhamod;
  printf("Escolha a modalidade da equipe (1 a %d): ", *contmod);
  scanf("%d", &escolhamod);
  getchar();
  
  if (escolhamod < 1 || escolhamod > *contmod) {
    printf("Escolha inválida.\n");
    return;
  }
  novaequipe.listaMod[novaequipe.quantMod] = modalidades[escolhamod - 1];
  novaequipe.quantMod++;

  int quantidadeAtletasModalidade = novaequipe.listaMod[0].quantAtleta;

  int escolha;
  printf("1- Adicionar atleta.\n");
  printf("2- Finalizar cadastro.\n");
  printf("Digite a opcao desejada: ");
  scanf("%d", &escolha);
  getchar();

  if(escolha == 1){
    if(novaequipe.quantAtleta >= 20){
      printf("Limite de atletas atingido.\n");
      return;
    }
    
    for(int i = 0; i < quantidadeAtletasModalidade; i++){
    printf("Digite o nome do %d atleta que deseja cadastrar: ", i + 1);
    fgets(atletas[*conAtl].nome, 50, stdin);
    printf("\n");

    int indiceAtl = -1;
    for(int i = 0; i < *conAtl; i++){
        if(strcmp(atletas[i].nome, atletas[*conAtl].nome) == 0){
            indiceAtl = i;
            break;
        }
    }

    if(indiceAtl == -1){
        printf("Atleta nao encontrado.\n");
        return;
  } 

    novaequipe.listaAtleta[novaequipe.quantAtleta] = atletas[indiceAtl];
    novaequipe.quantAtleta++;
}

} else if(escolha == 2){
  printf("Cadastro finalizado.\n");
    return;
    
  } else{
    printf("Escolha invalida\n");
   
  }

  equipes[*contequ] = novaequipe;
  (*contequ)++;
  
  printf("\nEquipe cadastrado com sucesso\n");
  printf("Dados da equipe.\n");
  printf("Nome da equipe: %s",  equipes[*contequ - 1].nome);
  printf("Sigla da equipe: %s", equipes[*contequ - 1].sigla);
  
  for(int i = 0; i < novaequipe.quantMod; i++){
    printf("Modalidade da equipe: %s", novaequipe.listaMod[i].mod);
  }
  
  printf("Quantidade de atletas na modalidade: %d\n", quantidadeAtletasModalidade);

  printf("Atletas da equipe.\n");
  for (int i = 0; i < novaequipe.quantAtleta; i++) {
    printf("\nDados do %d atleta cadastrado:\n", i +1);
    printf("Nome: %s", novaequipe.listaAtleta[i].nome);
    printf("CPF: %s", novaequipe.listaAtleta[i].cpf);
    printf("Sexo: %s", novaequipe.listaAtleta[i].sexo);
    printf("Instituição de Ensino: %s", novaequipe.listaAtleta[i].instituicao);
    printf("Data de Nascimento: %s", novaequipe.listaAtleta[i].nascimento);
    printf("\n");
  }
}

void excluirEquipe(struct equipe *equipes, int *contequ, struct torneio *torneios, int *conttorn, struct jogo *jogos, int *contjogo) {

  char sigla[5];
  int indiceEQU = -1;

   printf("\nDigite a sigla da equipe: ");
    fgets(sigla, 5, stdin); 

  for(int i = 0; i < *contequ; i++){
    if(strcmp(equipes[i].sigla, sigla) == 0){
      indiceEQU = i;
      break;
    }
  }

  if(indiceEQU == -1){
    printf("Equipe com sigla %s nao encontrada\n", sigla);
  } else {
    for(int i = 0; i < *conttorn; i++){
      for(int j = 0; j < torneios[i].quantequipe; j++){
        if(strcmp(torneios[i].listaequipe[j].sigla, sigla) == 0){
          for(int k = 0; k < torneios[i].quantequipe - 1; k++){
            torneios[i].listaequipe[k] = torneios[i].listaequipe[k + 1];
          }
          torneios[i].quantequipe--;
          break;
        }
      }
    }

    for(int i = indiceEQU; i < *contequ - 1; i++){
      equipes[i] = equipes[i + 1];
    }
  
  (*contequ)--;
  printf("Equipe excluida com sucesso\n");
  }
}

void atualizarEquipe(struct equipe *equipes, int *contequ, struct atleta *atletas, int *conAtl, struct modalidade *modalidades, int *contmod, struct torneio *torneios, int *conttorn){
  
  char sigla[5];
  
  printf("\nDigite a sigla da equipe que deseja atualizar: ");
  fgets(sigla, 5, stdin);

  int indice = -1;
    for (int i = 0; i < *contequ; i++) {
      if (strcmp(equipes[i].sigla, sigla) == 0) {
        indice = i;
        break;
      }
    }

    if (indice == -1) {
      printf("Equipe com sigla %s nao encontrada.\n", sigla);
      return;
    }
     
    int opcao;

    printf("\nEscolha a opcao que deseja atualizar:\n");
    printf("1. Alterar todos os dados\n");
    printf("2. nome\n");
    printf("3. sigla\n");
    printf("4. Modalidade da equipe\n");
    printf("5. Atletas da equipe\n");
    printf("6. Cancelar\n");
    printf("Escolha a opcao desejada: ");
    scanf("%d", &opcao);
    getchar();

    switch(opcao){
      
      case 1:
        printf("Novo nome: ");
        fgets(equipes[indice].nome, 50, stdin);
        for(int i = 0; i < *conttorn; i++){
          for(int j = 0; j < torneios[i].quantequipe; j++){
            if(strcmp(torneios[i].listaequipe[j].sigla, sigla) == 0){
              strcpy(torneios[i].listaequipe[j].nome, equipes[indice].nome);
            }
          }
        }
        printf("Novo Sigla: ");
        fgets(equipes[indice].sigla, 5, stdin);
        for(int i = 0; i < *conttorn; i++){
          for(int j = 0; j < torneios[i].quantequipe; j++){
            if(strcmp(torneios[i].listaequipe[j].sigla, sigla) == 0){
              strcpy(torneios[i].listaequipe[j].sigla, equipes[indice].sigla);
            }
          }
        }

        printf("Nova modalidae da equipe: ");
        fgets(equipes[indice].listaMod[0].mod, 50, stdin);
        for (int i = 0; i < *conttorn; i++) {
          for (int j = 0; j < torneios[i].quantequipe; j++) {
            if (strcmp(torneios[i].listaequipe[j].sigla, sigla) == 0) {
              for (int k = 0; k < torneios[i].listaequipe[j].quantMod; k++) {
                if (strcmp(torneios[i].listaequipe[j].listaMod[k].mod, equipes[indice].listaMod[0].mod) == 0) {
                  strcpy(torneios[i].listaequipe[j].listaMod[k].mod, equipes[indice].listaMod[0].mod);
                }
              }
            }
          }
        }

        printf("Novo atleta: \n");
        printf("Digite o nome do atleta que deseja alterar: ");
        fgets(atletas[*conAtl].nome, 50, stdin);
        
        int indiceAtl = -1;
        for(int i = 0; i < equipes[indice].quantAtleta; i++){
            if(strcmp(equipes[indice].listaAtleta[i].nome, atletas[*conAtl].nome ) == 0){
                indiceAtl = i;
                break;
           }
        }

        if(indiceAtl == -1){
            printf("Atleta nao encontrado.\n");
        } else {
            printf("Novo nome do atleta: ");
            fgets(equipes[indice].listaAtleta[indiceAtl].nome, 50, stdin);
            
          printf("Novo CPF: ");
          fgets(equipes[indice].listaAtleta[indiceAtl].cpf, 15, stdin);
            
          printf("Novo Sexo(M/F): ");
          fgets(equipes[indice].listaAtleta[indiceAtl].sexo, 2, stdin);
          getchar();
            
          printf("Nova Instituicao de Ensino: ");
          fgets(equipes[indice].listaAtleta[indiceAtl].instituicao, 50, stdin);
            
          printf("Nova Data de Nascimento(DD/MM/AAAA): ");
          fgets(equipes[indice].listaAtleta[indiceAtl].nascimento, 20, stdin);

          for(int i = 0; i < *conttorn; i++) {
            for(int j = 0; j < torneios[i].quantequipe; j++) {
              if(strcmp(torneios[i].listaequipe[j].sigla, sigla) == 0) {
                for(int k = 0; k < torneios[i].listaequipe[j].quantAtleta; k++) {
                  if(strcmp(torneios[i].listaequipe[j].listaAtleta[k].nome, atletas[*conAtl].nome) == 0) {
                    strcpy(torneios[i].listaequipe[j].listaAtleta[k].nome, equipes[indice].listaAtleta[indiceAtl].nome);
                    strcpy(torneios[i].listaequipe[j].listaAtleta[k].cpf, equipes[indice].listaAtleta[indiceAtl].cpf);
                    strcpy(torneios[i].listaequipe[j].listaAtleta[k].sexo, equipes[indice].listaAtleta[indiceAtl].sexo);
                    strcpy(torneios[i].listaequipe[j].listaAtleta[k].instituicao, equipes[indice].listaAtleta[indiceAtl].instituicao);
                    strcpy(torneios[i].listaequipe[j].listaAtleta[k].nascimento, equipes[indice].listaAtleta[indiceAtl].nascimento);
                  }
                }
              }
            }
          }
        }
        printf("Dados da equipe atualizados com sucesso\n");
        break;
    
      case 2:
        printf("Novo nome: ");
        fgets(equipes[indice]. nome, 50, stdin);
        for(int i = 0; i < *conttorn; i++){
          for(int j = 0; j < torneios[i].quantequipe; j++){
            if(strcmp(torneios[i].listaequipe[j].sigla, sigla) == 0){
              strcpy(torneios[i].listaequipe[j].nome, equipes[indice].nome);
            }
          }
        }
        printf("nome da equipe atualizados com sucesso\n");
        break;

      case 3:
        printf("Nova silga: ");
        fgets(equipes[indice].sigla, 5, stdin);
        for(int i = 0; i < *conttorn; i++){
          for(int j = 0; j < torneios[i].quantequipe; j++){
            if(strcmp(torneios[i].listaequipe[j].sigla, sigla) == 0){
              strcpy(torneios[i].listaequipe[j].sigla, equipes[indice].sigla);
            }
          }
        }
        printf("sigla da equipe atualizados com sucesso\n");
        break;

      case 4:
        printf("Nova modalidade da equipe: ");
        fgets(equipes[indice].listaMod[0].mod, 50, stdin);
        for (int i = 0; i < *conttorn; i++) {
          for (int j = 0; j < torneios[i].quantequipe; j++) {
            if (strcmp(torneios[i].listaequipe[j].sigla, sigla) == 0) {
              for (int k = 0; k < torneios[i].listaequipe[j].quantMod; k++) {
                if (strcmp(torneios[i].listaequipe[j].listaMod[k].mod, equipes[indice].listaMod[0].mod) == 0) {
                  strcpy(torneios[i].listaequipe[j].listaMod[k].mod, equipes[indice].listaMod[0].mod);
                }
              }
            }
          }
        }
        
        printf("modalidade da equipe atualizados com sucesso\n");
        break;

      case 5:
       printf("Digite o nome do atleta que deseja atualizar: ");
        fgets(atletas[*conAtl].nome, 50, stdin);
        
         indiceAtl = -1;
        for(int i = 0; i < equipes[indice].quantAtleta; i++){
            if(strcmp(equipes[indice].listaAtleta[i].nome, atletas[*conAtl].nome ) == 0){
                indiceAtl = i;
                break;
            }
        }

        if(indiceAtl == -1){
            printf("Atleta nao encontrado.\n");
        } else {
            printf("Novo nome do atleta: ");
            fgets(equipes[indice].listaAtleta[indiceAtl].nome, 50, stdin);
           
            printf("Novo CPF: ");
            fgets(equipes[indice].listaAtleta[indiceAtl].cpf, 15, stdin);
            
            printf("Novo Sexo(M/F): ");
            fgets(equipes[indice].listaAtleta[indiceAtl].sexo, 2, stdin);
            getchar();
            
            printf("Nova Instituicao de Ensino: ");
            fgets(equipes[indice].listaAtleta[indiceAtl].instituicao, 50, stdin);
            
            printf("Nova Data de Nascimento(DD/MM/AAAA): ");
            fgets(equipes[indice].listaAtleta[indiceAtl].nascimento, 20, stdin);

            for(int i = 0; i < *conttorn; i++) {
              for(int j = 0; j < torneios[i].quantequipe; j++) {
                if(strcmp(torneios[i].listaequipe[j].sigla, sigla) == 0) {
                  for(int k = 0; k < torneios[i].listaequipe[j].quantAtleta; k++) {
                    if(strcmp(torneios[i].listaequipe[j].listaAtleta[k].nome, atletas[*conAtl].nome) == 0) {
                      strcpy(torneios[i].listaequipe[j].listaAtleta[k].nome, equipes[indice].listaAtleta[indiceAtl].nome);
                      strcpy(torneios[i].listaequipe[j].listaAtleta[k].cpf, equipes[indice].listaAtleta[indiceAtl].cpf);
                      strcpy(torneios[i].listaequipe[j].listaAtleta[k].sexo, equipes[indice].listaAtleta[indiceAtl].sexo);
                      strcpy(torneios[i].listaequipe[j].listaAtleta[k].instituicao, equipes[indice].listaAtleta[indiceAtl].instituicao);
                      strcpy(torneios[i].listaequipe[j].listaAtleta[k].nascimento, equipes[indice].listaAtleta[indiceAtl].nascimento);
                    }
                  }
                }
              }
            } 
        }
        printf("Atleta da equipe atualizados com sucesso\n");
        break;

      case 6:
        printf("Opcao cancelada\n");
        default:
        printf("Opcao invalida\n");
    
    (*contequ)++;
    }
}

void registroEquipe(struct equipe *equipes, int *contequ, struct atleta *atletas, int *conAtl, struct modalidade *modalidades, int *contmod) {
    
    char sigla[5];
    
    printf("\nDigite a sigla do jogo: ");
    fgets(sigla, 5, stdin);
    
    int indice = -1;
    for (int i = 0; i < *contequ; i++) {
      if (strcmp(equipes[i].sigla, sigla) == 0) {
        indice = i;
        break;
      }
    }
    if(indice == -1){
      printf("Equipe com sigla %s nao encotrada\n", sigla);
    } else {
        printf("Detalhes da equipe com sigla: %s\n", sigla);
        printf("Nome da equipe: %s", equipes[indice].nome);
        printf("Sigla da equipe: %s", equipes[indice].sigla);
      
        for(int i = 0; i < equipes[indice].quantMod; i++){
          int indicemod = -1;
          for(int j = 0; j < *contmod; j++){
            if(strcmp(equipes[indice].listaMod[i].mod, modalidades[j].mod) == 0){
            indicemod = j;
            break;
          }
        }
        
        if(indicemod == -1){
          printf("Sem modalidade.\n");
        } else {
          printf("Modalidade: %s", modalidades[indicemod].mod);
          printf("Quantidade de atletas na equipe: %d\n", modalidades[indicemod].quantAtleta);
        }
        }
  
        printf("\nAtletas: \n");
        for(int j = 0; j < equipes[indice].quantAtleta; j++){

          int indiceatl = -1;
          for(int n = 0; n < *conAtl; n++){
            if(strcmp(equipes[indice].listaAtleta[j].nome, atletas[n].nome) == 0){
              indiceatl = n;
              break;
            }
          }

          if(indiceatl == -1){
            printf("Sem atleta.\n");
          } else{
            printf("Atleta %d.\n", j + 1);
            printf("Nome: %s", atletas[indiceatl].nome);
            printf("CPF: %s", atletas[indiceatl].cpf);
            printf("Sexo: %s", atletas[indiceatl].sexo);
            printf("Instituição de ensino: %s", atletas[indiceatl].instituicao);
            printf("Data de nascimento: %s\n", atletas[indiceatl].nascimento);
       }
    }  
  }
}

void registroGeralEquipe(struct equipe *equipes, int *contequ, struct atleta *atletas, int *conAtl, struct modalidade *modalidades, int *contmod) {
  
   if (*contequ == 0) {
      printf("SEM REGISTRO\n");
      return; 
    }

  printf("\nRegistro geral das equipes.\n");
  for (int i = 0; i < *contequ; i++) {
    printf("Equipe %d:\n", i + 1);
    printf("Nome da equipe: %s", equipes[i].nome);
    printf("Sigla da equipe: %s", equipes[i].sigla);
    
    for(int m = 0; m < equipes[i].quantMod; m++){
      printf("Moldaidade: %s", equipes[i].listaMod[m].mod);
    }
    
    printf("\nAtleta:\n ");
    for (int a = 0; a < equipes[i].quantAtleta; a++) {
      printf("Atleta %d:\n", a + 1);
      printf("Nome: %s", equipes[i].listaAtleta[a].nome);
      printf("CPF: %s", equipes[i].listaAtleta[a].cpf);
      printf("Sexo: %s", equipes[i].listaAtleta[a].sexo);
      printf("Instituicao de ensino: %s", equipes[a].listaAtleta[a].instituicao);
      printf("Data de nascimento: %s\n", equipes[i].listaAtleta[a].nascimento);
      printf("\n");
    }
  }
}

void submenuEquipe(struct equipe *equipes, int *contequ, struct atleta *atletas, int *conAtl, struct modalidade *modalidades, int *contmod, struct torneio *torneios, int *conttorn, struct jogo *jogos, int *contjogo){
  int escolha;

  do {
    printf("\nMenu equipe:\n");
    printf("1. Cadastar\n");
    printf("2. Excluir\n");
    printf("3. Atualizar\n");
    printf("4. Exibir registro\n");
    printf("5. Exibir todos os registros\n");
    printf("6. Sair do sistema\n");
    printf("\n");

    printf("Escolha a opcao desejada: ");
    scanf("%d", &escolha);
    getchar();

    switch(escolha) {

      case 1:
        cadastroEquipe(equipes, &*contequ, atletas, &*conAtl, modalidades, &*contmod);
        break;;
      
      case 2:
        excluirEquipe(equipes, &*contequ, torneios, &*conttorn, jogos, &*contjogo);
        break;
      
      case 3:
        atualizarEquipe(equipes, &*contequ, atletas, &*conAtl, modalidades, &*contmod, torneios, &*conttorn);
        break;

      case 4:
        registroEquipe(equipes, &*contequ, atletas, &*conAtl, modalidades, &*contmod);
        break;
      
      case 5:
        registroGeralEquipe(equipes, &*contequ, atletas, &*conAtl, modalidades, &*contmod);
        break;
        default:
        printf("Opcao invalida, tente novamente\n");
    }

  } while(escolha != 6);

} 