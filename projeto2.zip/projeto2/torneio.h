#ifndef TORNEIO_H
#define TORNEIO_H
#include "estruturas.h"
#include "atleta.h"
#include "modalidade.h"
#include "equipe.h"
#include "jogo.h"

void cadastroTorneio(struct torneio *torneios, int *conttorn, struct modalidade *modalidades, int *contmod, struct equipe *equipes, int *contequ, struct atleta *atletas, int *conAtl);
void excluirTorneio(struct torneio *torneios, int *conttorn);
void atualizarTorneio(struct torneio *torneios, int *conttorn, struct modalidade *modalidades, int *contmod, struct equipe *equipes, int *contequ, struct jogo *jogos, int *contjogo);
void registroTorneio(struct torneio *torneios, int *conttorn, struct modalidade *modalidades, int *contmod, struct equipe *equipes, int *contequ);
void exibirJogosTorneio(struct jogo *jogos, int contjogo, const char *nomeTorneio);
void registrosGeralTorneio(struct torneio *torneios, int *conttorn, struct modalidade *modalidades, int *contmod, struct equipe *equipes, int *contequ);
void submenuTorneio(struct torneio *torneios, int *conttorn, struct modalidade *modalidades, int *contmod, struct equipe *equipes, int *contequ, struct atleta *atletas, int *conAtl, struct jogo *jogos, int *contjogo);

#endif // TORNEIO_H