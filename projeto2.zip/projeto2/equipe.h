#ifndef EQUIPE_H
#define EQUIPE_H
#include "estruturas.h"
#include "atleta.h"
#include "modalidade.h"
#include "torneio.h"
#include "jogo.h"

void cadastroEquipe(struct equipe *equipes, int *contequ, struct atleta *atletas, int *conAtl, struct modalidade *modalidades, int *contmod);
void excluirEquipe(struct equipe *equipes, int *contequ, struct torneio *torneios, int *conttorn, struct jogo *jogos, int *contjogo);
void atualizarEquipe(struct equipe *equipes, int *contequ, struct atleta *atletas, int *conAtl, struct modalidade *modalidades, int *contmod, struct torneio *torneios, int *conttorn);
void registroEquipe(struct equipe *equipes, int *contequ, struct atleta *atletas, int *conAtl, struct modalidade *modalidades, int *contmod);
void registroGeralEquipe(struct equipe *equipes, int *contequ, struct atleta *atletas, int *conAtl, struct modalidade *modalidades, int *contmod);
void submenuEquipe(struct equipe *equipes, int *contequ, struct atleta *atletas, int *conAtl, struct modalidade *modalidades, int *contmod, struct torneio *torneios, int *conttorn,struct jogo *jogos, int *contjogo);

#endif // EQUIPE_H