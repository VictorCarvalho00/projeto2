#ifndef MODALIDADE_H
#define MODALIDADE_H
#include "estruturas.h"
#include "atleta.h"
#include "equipe.h"

void cadastroMod(struct modalidade *modalidades, int *contmod);
void excluirMod(struct modalidade *modalidades, int *contmod, struct equipe *equipes, int *contequ);
void atualizarMod(struct modalidade *modalidades, int *contmod, struct equipe *equipes, int *contequ);
void registromod(struct modalidade *modalidades, int *contmod);
void registrogeralMOD(struct modalidade *modalidades, int *contmod);
void submenuMod(struct modalidade *modalidades, int *contmod, struct equipe *equipes, int *contequ);

#endif // MODALIDADE_H



