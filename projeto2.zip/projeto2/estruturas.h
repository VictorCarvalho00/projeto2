#ifndef ESTRUTURAS_H
#define ESTRUTURAS_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct atleta
{
  char nome[50];
  char cpf[15];
  char sexo[2];
  char instituicao[50];
  char nascimento[20];
};

struct modalidade
{
  char mod[50];
  int quantAtleta;
};

struct equipe
{
  char nome[50];
  char sigla[5];
  struct modalidade listaMod[50];
  struct atleta listaAtleta[20];
  int quantAtleta;
  int quantMod; 
};

struct torneio
{
  char nomeTorneio[50];
  struct modalidade listamod[50];
  struct equipe listaequipe[8];
  int quantmod;
  int quantequipe;
  char escolhamod[50];
};

struct jogo
{
  char nometorneio[50];
  char dataHora[20];
  char p1[10];
  char p2[10];
  char identificador[50];
  char sigla1[5];
  char sigla2[5];
};

#endif // ESTRUTURAS_H