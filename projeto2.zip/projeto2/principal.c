#include "estruturas.h"
#include"atleta.h"
#include "modalidade.h"
#include "equipe.h"
#include "torneio.h"
#include "jogo.h"

struct atleta atletas[100];
struct modalidade modalidades[100];
struct equipe equipes[100];
struct torneio torneios[100];
struct jogo jogos [100];

  int conAtl = 0;
  int contMod = 0;
  int contequ =  0;
  int conttorn = 0;
  int contjogo = 0;

int main()
{
  
  
  int escolha;
  
  do
  {
    printf("1. Sistema de Cadastro de Atletas\n");
    printf("2. Sistema de Cadastro de Modalidades\n");
    printf("3. Sistema de Cadastro de Equipes\n ");
    printf("4. Sistema deadast Cadastro de Torneios\n");
    printf("5. Sistema de Cadastro de Jogos\n");
    printf("6. Sair do sistema\n");
    printf("\n");

    printf("Escolha a opcao desejada: ");
    scanf("%d", &escolha);
    getchar();

    switch (escolha)
    {

    case 1:
      submenuAtlta(atletas, &conAtl, equipes, &contequ);
      break;

    case 2:
      submenuMod(modalidades, &contMod, equipes, &contequ);
      break;

    case 3:
      submenuEquipe(equipes, &contequ, atletas, &conAtl, modalidades, &contMod, torneios, &conttorn, jogos, &contjogo);
      break;

    case 4:
      submenuTorneio(torneios, &conttorn, modalidades, &contMod, equipes, &contequ, atletas, &conAtl, jogos, &contjogo);
      break;

    case 5:
      submenuJogo(jogos, &contjogo, torneios, &conttorn);
      break;

    case 6:
      printf("Sair do sistema");
      break;
    default:
      printf("Opcao invalida, tente novamente");
    
    }

  } while (escolha != 6);

  return 0;
}