#ifndef ATLETA_H
#define ATLETA_H
#include "estruturas.h"
#include "equipe.h"

void cadastroAtleta(struct atleta *atletas, int *conAtl);
void excluirAtleta(struct atleta atletas[], int *conAtl, struct equipe equipes[], int *contequ);
void atualizarAtleta(struct atleta *atletas, int *conAtl, struct equipe *equipes, int *contequ);
void registroAtleta(struct atleta atletas[], int *conAtl);
void registrosGeralATL(struct atleta *atletas, int *conAtl);
void submenuAtlta(struct atleta *atletas, int *conAtl, struct equipe *equipes, int *contequ);

#endif // ATLETA_H