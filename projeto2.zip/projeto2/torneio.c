#include "estruturas.h"
#include "torneio.h"
#include "atleta.h"
#include "modalidade.h"
#include "equipe.h"
#include "jogo.h"

void cadastroTorneio(struct torneio *torneios, int *conttorn, struct modalidade *modalidades, int *contmod, struct equipe *equipes, int *contequ, struct atleta *atletas, int *conAtl)
{
    if(*conttorn > 10)
    {
        printf("Limite de torneios atingidos");
        return;
    }

    struct torneio novotorneio;
    novotorneio.quantmod = 0;
    novotorneio.quantequipe = 0;

    printf("\nNome do torneio: ");
    fgets(novotorneio.nomeTorneio, 50, stdin);

    int confirmarMOD = 0;
    int tentativasMOD = 0;

    while(!confirmarMOD && tentativasMOD < 3)
    {
        printf("Modalidade da equipe: ");
        fgets(novotorneio.escolhamod, 50, stdin);

        for(int i = 0; i < *contmod; i++)
        {
            if(strcmp(modalidades[i].mod, novotorneio.escolhamod) == 0)
            {
                confirmarMOD = 1;
                break;
            }
        }

        if(!confirmarMOD)
        {
            printf("Modalidade nao encontrada.\n");
            tentativasMOD++;
        }
    }

    if(tentativasMOD == 3 && !confirmarMOD)
    {
        printf("Número máximo de tentativas atingido. Cadastro finalizado sem salvar.\n");
        return;
    }

    int opcao;
    printf("1- Adicionar equipe.\n");
    printf("2- Finalizar cadastro.\n");
    printf("Digite a opcao desejada: ");
    scanf("%d", &opcao);
    getchar();

    if(opcao == 1)
    {
        if(novotorneio.quantequipe >= 8)
        {
            printf("Limite de equipes atingido.\n");
            return;
        }

        printf("Equipes cadastradas:\n ");
        for(int o = 0; o < *contequ; o++)
        {
            printf("Nome da %d equipe: %s", o + 1, equipes[o].nome);
            printf("Sigla da %d equipe: %s", o + 1, equipes[o].sigla);
            printf("\n");
        }

        int escolha;
        printf("Quantas equipes deseja cadastar ? ");
        scanf("%d", &escolha);
        getchar();

        if(escolha + novotorneio.quantequipe > 8)
        {
            printf("Quantidade de equipes excede o limite permitido.\n");
            return;
        }

        for(int i = 0; i < escolha; i++)
        {
            int verificarEQ = 0;
            int tentativas = 0;

            while(!verificarEQ && tentativas < 3)
            {
                printf("Digite a sigla da %d equipe que deseja cadastar: ", 1 + i);
                char SIGLA[5];
                fgets(SIGLA, 5, stdin);

                int buscarEQ = 0;
                for(int y = 0; y <*contequ; y++)
                {
                    if(strcmp(equipes[y].sigla, SIGLA) == 0)
                    {

                        int verificarMOD = 0;
                        for(int m = 0; m < equipes[y].quantMod; m++)
                        {
                            if(strcmp(equipes[y].listaMod[m].mod, novotorneio.escolhamod) == 0)
                            {
                                verificarMOD = 1;
                                break;
                            }
                        }

                        if(verificarMOD)
                        {

                            novotorneio.listaequipe[novotorneio.quantequipe] = equipes[y];
                            novotorneio.quantequipe++;
                            verificarEQ = 1;

                        }
                        else
                        {
                            printf("Equipe com sigla %s nao pertence a modalidade digitada.\n", SIGLA);
                        }
                        buscarEQ = 1;
                        break;
                    }
                }

                if(!buscarEQ)
                {
                    printf("Equipe com sigla %s nao encontrada\n", SIGLA);
                    tentativas++;
                }

                if(tentativas == 3 && !verificarEQ)
                {
                    printf("Número máximo de tentativas atingido. Cadastro finalizado sem salvar.\n");
                    return;
                }
            }
        }
    }
    else if(opcao == 2)
    {
        printf("Cadastro finalizado.\n");
        return;

    }
    else
    {
        printf("Escolha invalida\n");
    }

    torneios[*conttorn] = novotorneio;
    (*conttorn)++;

    printf("\nTorneio cadastrado com sucesso.");
    printf("\nDados do torneio.\n");

    printf("\nNome do torneio: %s", novotorneio.nomeTorneio);
    printf("Modalidade da equipe: %s", novotorneio.escolhamod);
    printf("Quantidade de equipes inscritas: %d\n", novotorneio.quantequipe);

    printf("lista de equipes inscritas.\n");
    for(int k = 0; k < novotorneio.quantequipe; k++)
    {
        printf("\nDados da %d equipe.\n", k + 1);
        printf("Nome da equipe: %s",novotorneio.listaequipe[k].nome);
        printf("Sigla da equipe: %s", novotorneio.listaequipe[k].sigla);
        printf("Atletas da equipe\n");

        for(int a = 0; a < novotorneio.listaequipe[k].quantAtleta; a++)
        {
            printf("Nome do %d atleta: \n%s", a + 1, novotorneio.listaequipe[k].listaAtleta[a].nome);
        }
    }
}

void excluirTorneio(struct torneio *torneios, int *conttorn)
{

    char nomeTorneio[50];
    int indice = -1;

    printf("\nDigite o nome do torneio: ");
    fgets(nomeTorneio, 15, stdin);

    for (int i = 0; i < *conttorn; i++)
    {
        if (strcmp(torneios[i].nomeTorneio, nomeTorneio) == 0)
        {
            indice = i;
            break;
        }
    }

    if (indice == -1)
    {
        printf("Torneio com nome %s não encontrado.\n", nomeTorneio);
    }
    else
    {
        for (int i = indice; i < (*conttorn) - 1; i++)
        {
            torneios[i] = torneios[i + 1];
        }
        (*conttorn)--;
        printf("Torneio %s excluído com sucesso.\n", nomeTorneio);
    }
}

void atualizarTorneio(struct torneio *torneios, int *conttorn, struct modalidade *modalidades, int *contmod, struct equipe *equipes, int *contequ, struct jogo *jogos, int *contjogo)
{

    char nomeTorneio[50];
    printf("Digite o nome do torneio que deseja atualizar: ");
    fgets(nomeTorneio, 50, stdin);

    int indice = -1;
    for (int i = 0; i < *conttorn; i++)
    {
        if (strcmp(torneios[i].nomeTorneio, nomeTorneio) == 0)
        {
            indice = i;
            break;
        }
    }

    if (indice == -1)
    {
        printf("Torneio com nome '%s' não encontrado.\n", nomeTorneio);
        return;
    }

    int opcao;
    char novoNome[50];

    printf("\nEscolha a opcao que deseja atualizar:\n");
    printf("1. Alterar todos os dados:\n");
    printf("2. Nome do torneio\n");
    printf("3. Modalidade\n");
    printf("4. Quantidade de equipes inscritas\n");
    printf("5. Lista de equipes inscritas\n");
    printf("6. Cancelar\n");
    printf("Escolha a opcao desejada: ");
    scanf("%d", &opcao);
    getchar();

    switch (opcao)
    {
    case 1:
        printf("Novo nome do torneio: ");
        fgets(torneios[indice].nomeTorneio, 50, stdin);
        for (int i = 0; i < *contjogo; i++)
        {
            if (strcmp(jogos[i].nometorneio, nomeTorneio) == 0)
            {
                strcpy(jogos[i].nometorneio, torneios[indice].nomeTorneio);
            }
        }

        printf("Nova modalidade: ");
        fgets(torneios[indice].escolhamod, 50, stdin);

        int novaQuantidade;
        printf("Nova quantidade de equipes: ");
        scanf("%d", &novaQuantidade);
        getchar();

        if(novaQuantidade > 8)
        {
            printf("Quantidade de equipes excede  o limte permitido.\n");
            return;
        }
        torneios[indice].quantequipe = novaQuantidade;

        printf("Nova lista de inscritos");
        for(int i = 0; i < novaQuantidade; i++)
        {
            printf("Digite a sigla da %d equipe: ", i + 1);
            fgets(equipes[*contequ].sigla, 5, stdin);
            printf("\n");

            int indiceEQUIPE = -1;
            for(int j = 0; j < *contequ; j++)
            {
                if(strcmp(equipes[j].sigla, equipes[*contequ].sigla) == 0)
                {
                    indiceEQUIPE = j;
                    break;
                }
            }

            if(indiceEQUIPE == -1)
            {
                printf("Equipe nao encontrada.\n");
                return;
            }
            torneios[indice].listaequipe[i] = equipes[indiceEQUIPE];
        }
        break;

    case 2:
        printf("Novo nome do torneio: ");
        fgets(torneios[indice].nomeTorneio, 50, stdin);
        for (int i = 0; i < *contjogo; i++)
        {
            if (strcmp(jogos[i].nometorneio, nomeTorneio) == 0)
            {
                strcpy(jogos[i].nometorneio, torneios[indice].nomeTorneio);
            }
        }
        break;

    case 3:
        printf("Nova modalidade: ");
        fgets(torneios[indice].listamod[0].mod, 50, stdin);
        break;

    case 4:
        printf("Nova quantidade de equipes: ");
        scanf("%d", &novaQuantidade);
        getchar();
        if(novaQuantidade > 8)
        {
            printf("Quantidade de equipes excede  o limte permitido.\n");
            return;
        }
        torneios[indice].quantequipe = novaQuantidade;
        break;

    case 5:
        printf("Nova lista de incritos: ");
        for(int i = 0; i <novaQuantidade; i++)
        {
            printf("Digite a sigla da %d equipe: ", i + 1);
            fgets(equipes[*contequ].sigla, 5, stdin);
            printf("\n");

            int indiceEQUIPE = -1;
            for(int j = 0; j < *contequ; j++)
            {
                if(strcmp(equipes[j].sigla, equipes[*contequ].sigla) == 0)
                {
                    indiceEQUIPE = j;
                    break;
                }
            }

            if(indiceEQUIPE == -1)
            {
                printf("Equipe nao encontrada.\n");
                return;
            }
            torneios[indice].listaequipe[i] = equipes[indiceEQUIPE];
        }
        break;

    case 6:
        printf("Opção cancelada.\n");
        break;
    default:
        printf("Opção inválida.\n");
        break;
    }
}

void registroTorneio(struct torneio *torneios, int *conttorn, struct modalidade *modalidades, int *contmod, struct equipe *equipes, int *contequ)
{

    char nomeTorneio[50];

    printf("\nDigite o nome do torneio que deseja visualizar: ");
    fgets(nomeTorneio, 50, stdin);

    int indice = -1;
    for(int i = 0; i < *conttorn; i++)
    {
        if(strcmp(torneios[i].nomeTorneio, nomeTorneio) == 0)
        {
            indice = i;
            break;
        }
    }

    if(indice == -1)
    {
        printf("Torneio com nome %s nao encontrado:\n", nomeTorneio);
    }
    else
    {
        printf("\nDetalhes do torneio: %s\n", nomeTorneio);
        printf("Nome do torneio: %s", torneios[indice].nomeTorneio);
        printf("Modelidade do torneio: %s", torneios[indice].escolhamod);
        printf("Quantidade de equipe inscrita: %d\n", torneios[indice].quantequipe);

        for(int j = 0; j < torneios[indice].quantequipe; j++)
        {
            int indiceEQUIPE = -1;
            for(int n = 0; n < *contequ; n++)
            {
                if(strcmp(torneios[indice].listaequipe[j].sigla, equipes[n].sigla) == 0)
                {
                    indiceEQUIPE = n;
                    break;
                }
            }

            if(indiceEQUIPE == -1)
            {
                printf("Sem equipe.\n");
            }
            else
            {
                printf("\nequipe %d.\n", j + 1);
                printf("Nome da %d equipe: %s", j + 1, equipes[indiceEQUIPE].nome);
                printf("Sigla da %d equipe: %s",j + 1, equipes[indiceEQUIPE].sigla);

                printf("Atletas.\n");

                for (int k = 0; k < equipes[indiceEQUIPE].quantAtleta; k++)
                {
                    printf("\nNome do %d atletas: \n%s", k + 1, equipes[indiceEQUIPE].listaAtleta[k].nome);
                    printf("\n");
                }
            }
        }
    }
}

void registrosGeralTorneio(struct torneio *torneios, int *conttorn, struct modalidade *modalidades, int *contmod, struct equipe *equipes, int *contequ)
{

    if (*conttorn == 0)
    {
        printf("SEM REGISTRO\n");
        return;
    }

    printf("\nRegistros de todos os torneios.\n");
    for (int i = 0; i < *conttorn; i++)
    {
        printf("\nTorneio %d:\n", i + 1);
        printf("Nome do torneio: %s", torneios[i].nomeTorneio);
        printf("Modelidade do torneio: %s", torneios[i].escolhamod);
        printf("Quantidade de equipe inscrita: %d\n", torneios[i].quantequipe);

        printf("Lista da %d equipe inscrita.\n", i + 1);

        for(int k = 0; k < torneios[i].quantequipe; k++)
        {
            printf("\nEquipe %d:\n", k + 1);
            printf("Nome da equipe: %s", torneios[i].listaequipe[k].nome);
            printf("Sigla da equipe: %s", torneios[i].listaequipe[k].sigla);

            printf("Atletas da equipe: %s\n", torneios[i].listaequipe[k].nome);

            for(int j = 0; j < torneios[i].listaequipe[k].quantAtleta; j++)
            {
                printf("Nome do %d atleta: \n%s", j + 1,torneios[i].listaequipe[k].listaAtleta[j].nome);
            }
        }
    }
}

void exibirJogosTorneio(struct jogo *jogos, int contjogo, const char *nomeTorneio)
{

    for (int i = 0; i < contjogo - 1; i++)
    {
        for (int j = i + 1; j < contjogo; j++)
        {
            if (strcmp(jogos[i].dataHora, jogos[j].dataHora) > 0)
            {
                struct jogo temp = jogos[i];
                jogos[i] = jogos[j];
                jogos[j] = temp;
            }
        }
    }

    int encontrouJogos = 0;
    printf("Jogos do torneio: %s\n", nomeTorneio);

    for (int i = 0; i < contjogo; i++)
    {
        if (strcmp(jogos[i].nometorneio, nomeTorneio) == 0)
        {
            printf("\nData e horário do %d jogo: %s",i + 1, jogos[i].dataHora);
            printf("\nSigla da primeira equipe: %s\n", jogos[i].sigla1);
            printf("Sigla da segunda equipe: %s\n", jogos[i].sigla2);
            printf("Identificador do jogo: %s", jogos[i].identificador);
            printf("\nPLACAR:\n");
            printf("Pontuação do primeiro time: %s\n", jogos[i].p1);
            printf("Pontuação do segundo time: %s\n", jogos[i].p2);
            encontrouJogos = 1;
        }
    }

    if (!encontrouJogos)
    {
        printf("Nenhum jogo encontrado para o torneio '%s'.\n", nomeTorneio);
    }
}

void submenuTorneio(struct torneio *torneios, int *conttorn, struct modalidade *modalidades, int *contmod, struct equipe *equipes, int *contequ, struct atleta *atletas, int *conAtl, struct jogo *jogos, int *contjogo)
{

    int escolha;

    do
    {
        printf("\nMenu torneio:\n");
        printf("1. Cadastar\n");
        printf("2. Excluir\n");
        printf("3. Atualizar\n");
        printf("4. Exibir registro\n");
        printf("5. Exibir todos os registros\n");
        printf("6. Exibir jogos de um torneio\n");
        printf("7. Sair do sistema");
        printf("\n");

        printf("Escolha a opcao desejada: ");
        scanf("%d", &escolha);
        getchar();

        switch(escolha)
        {

        case 1:
            cadastroTorneio(torneios, &*conttorn, modalidades, &*contmod, equipes, &*contequ, atletas, &*conAtl);
            break;

        case 2:
            excluirTorneio(torneios, &*conttorn);
            break;


        case 3:
            atualizarTorneio(torneios, &*conttorn, modalidades, &*contmod, equipes, &*contequ, jogos, &*contjogo);
            break;

        case 4:
            registroTorneio(torneios, &*conttorn, modalidades, &*contmod, equipes, &*contequ);
            break;

        case 5:
            registrosGeralTorneio(torneios, &*conttorn, modalidades, &*contmod, equipes, &*contequ);
            break;

        case 6:
            char nomeTorneio[50];
            printf("Digite o nome do torneio para exibir os jogos: ");
            fgets(nomeTorneio, 50, stdin);
            exibirJogosTorneio(jogos, *contjogo, nomeTorneio);
            break;
        default:
            printf("Opcao invalida, tente novamente\n");
            printf("\n");
        }

    }
    while(escolha != 7);
}