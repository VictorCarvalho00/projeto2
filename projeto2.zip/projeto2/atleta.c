#include "estruturas.h"
#include "atleta.h"
#include "equipe.h"

void cadastroAtleta(struct atleta *atletas, int *conAtl){
  
  if(*conAtl > 100){
    printf("Limite de atletas atingidos");
    return;
  }

  struct atleta novoatleta;

printf("\nNome: ");
fgets(novoatleta.nome, 50, stdin);
    
printf("CPF: ");
fgets(novoatleta.cpf, 15, stdin);
    
printf("Sexo(M/F): ");
fgets(novoatleta.sexo, 2, stdin);
getchar();
    
printf("Instituicao de Ensino: ");
fgets(novoatleta.instituicao, 50, stdin);
   
printf("Data de Nascimento(DD/MM/AAAA): ");
fgets(novoatleta.nascimento, 20, stdin);
   
atletas[*conAtl] = novoatleta;
(*conAtl)++;

printf("\nAtleta cadastrado com sucesso.");
printf("\nDados do atleta.\n");

for (int i = 0; i < *conAtl; i++){
  printf("Nome: %s", atletas[i].nome);
  printf("CPF: %s", atletas[i].cpf);
  printf("Sexo: %s\n", atletas[i].sexo);
  printf("Instituicao de ensino: %s", atletas[i].instituicao);
  printf("Data de nascimento: %s\n",atletas[i].nascimento);
 } 
}

void excluirAtleta(struct atleta atletas[], int *conAtl, struct equipe equipes[], int *contequ) {
    
    char cpf[15];
    int indice = -1;
    
    printf("\nDigite o CPF do atelta: ");
    fgets(cpf, 15, stdin);

    for(int i = 0; i < *conAtl; i++){
      if(strcmp(atletas[i].cpf,cpf) == 0){
        indice = i;
        break;
      }
    }

    if(indice == -1){
      printf("Atleta com CPF %s nao foi encontrado\n", cpf);
      return;
    } else {
      for(int i = 0; i < *contequ; i++){
        for(int j = 0; j < equipes[i].quantAtleta; j++){
          if(strcmp(equipes[i].listaAtleta[j].cpf, cpf) == 0){
            for(int k = j; k < equipes[i].quantAtleta - 1; k++){
              equipes[i].listaAtleta[k] = equipes[i].listaAtleta[k + 1];
            }
            equipes[i].quantAtleta--;
            break;
          }
        }
      }
      
      for(int i = indice; i < *conAtl - 1; i++){
        atletas[i] = atletas[i + 1];
      }
      
      (*conAtl)--;
      printf("Atleta com CPF %s excluido com sucesso\n", cpf);
   }
}

void atualizarAtleta(struct atleta *atletas, int *conAtl, struct equipe *equipes, int *contequ){
  
  char cpf[15];
  
  printf("\nDigite o CPF do atleta que deseja atualizar: ");
  fgets(cpf, 15, stdin);

  int indice = -1;
  for(int i = 0; i < *conAtl; i++){
    if(strcmp(atletas[i].cpf, cpf)== 0){
      indice = i;
      break;
    }
  }
   if(indice == -1){
    printf("CPF invalido");
    return;
   }

   int opcao;

   printf("\nEscolha a opcao que deseja atualizar:\n");
   printf("1. Alterar todos os dados\n");
   printf("2. nome\n");
   printf("3. CPF\n");
   printf("4. sexo\n");
   printf("5. Instituicao de ensino\n");
   printf("6. Data de nascimento\n");
   printf("7. Cancelar\n");
   printf("Escolha a opcao desejada: ");
   scanf("%d", &opcao);
   getchar(); 
  
   switch(opcao){
    
    case 1:
      printf("Novo nome: ");
      fgets(atletas[indice].nome, 50, stdin);
      for(int i = 0; i < *contequ; i++){
        for(int j = 0; j < equipes[i].quantAtleta; j++){
          if(strcmp(equipes[i].listaAtleta[j].cpf, cpf) == 0){
            strcpy(equipes[i].listaAtleta[j].nome, atletas[indice].nome);
          }
        }
      }
      printf("Novo CPF: ");
      fgets(atletas[indice].cpf, 15, stdin);
      for(int i = 0; i < *contequ; i++){
        for(int j = 0; j < equipes[i].quantAtleta; j++){
          if(strcmp(equipes[i].listaAtleta[j].cpf, cpf) == 0){
            strcpy(equipes[i].listaAtleta[j].cpf, atletas[indice].cpf);
          }
        }
      }
      printf("Novo sexo (M/F): ");
      fgets(atletas[indice].sexo, 2, stdin);
      getchar();
      for(int i = 0; i < *contequ; i++){
        for(int j = 0; j < equipes[i].quantAtleta; j++){
          if(strcmp(equipes[i].listaAtleta[j].cpf, cpf) == 0){
            strcpy(equipes[i].listaAtleta[j].sexo, atletas[indice].sexo);
          }
        }
      }
      printf("Nova instituicao de ensino: ");
      fgets(atletas[indice].instituicao, 50, stdin);
      for(int i = 0; i < *contequ; i++){
        for(int j = 0; j < equipes[i].quantAtleta; j++){
          if(strcmp(equipes[i].listaAtleta[j].cpf, cpf) == 0){
            strcpy(equipes[i].listaAtleta[j].instituicao, atletas[indice].instituicao);
          }
        }
      }
      printf("Nova data de nascimento: ");
      fgets(atletas[indice].nascimento, 20, stdin);
      for(int i = 0; i < *contequ; i++){
        for(int j = 0; j < equipes[i].quantAtleta; j++){
          if(strcmp(equipes[i].listaAtleta[j].cpf, cpf) == 0){
            strcpy(equipes[i].listaAtleta[j].nascimento, atletas[indice].nascimento);
          }
        }
      }
      printf("Dados do atleta atualizados com sucesso\n");
      break;
      
    case 2:
      printf("Novo nome: ");
      fgets(atletas[indice].nome, 50, stdin);
      for(int i = 0; i < *contequ; i++){
        for(int j = 0; j < equipes[i].quantAtleta; j++){
          if(strcmp(equipes[i].listaAtleta[j].cpf, cpf) == 0){
            strcpy(equipes[i].listaAtleta[j].nome, atletas[indice].nome);
          }
        }
      }
      printf("nome do atleta atualizados com sucesso\n");
      break;

    case 3:
      printf("Novo CPF: ");
      fgets(atletas[indice].cpf, 15, stdin);
      for(int i = 0; i < *contequ; i++){
        for(int j = 0; j < equipes[i].quantAtleta; j++){
          if(strcmp(equipes[i].listaAtleta[j].cpf, cpf) == 0){
            strcpy(equipes[i].listaAtleta[j].cpf, atletas[indice].cpf);
          }
        }
      }
      printf("CPF do atleta atualizados com sucesso\n");
      break;

    case 4:
      printf("Novo sexo: ");
      fgets(atletas[indice].sexo, 2, stdin);
      getchar();
      for(int i = 0; i < *contequ; i++){
        for(int j = 0; j < equipes[i].quantAtleta; j++){
          if(strcmp(equipes[i].listaAtleta[j].cpf, cpf) == 0){
            strcpy(equipes[i].listaAtleta[j].sexo, atletas[indice].sexo);
          }
        }
      }
      printf("Sexo do atleta atualizados com sucesso\n");
      break;

    case 5: 
      printf("Novo instituicao: ");
      fgets(atletas[indice].instituicao, 50, stdin);
      for(int i = 0; i < *contequ; i++){
        for(int j = 0; j < equipes[i].quantAtleta; j++){
          if(strcmp(equipes[i].listaAtleta[j].cpf, cpf) == 0){
            strcpy(equipes[i].listaAtleta[j].instituicao, atletas[indice].instituicao);
          }
        }
      }
      printf("Instituicao do atleta atualizados com sucesso\n");
      break;

    case 6:
      printf("Nova data de nascimento: ");
      fgets(atletas[indice].nascimento, 20, stdin);
      for(int i = 0; i < *contequ; i++){
        for(int j = 0; j < equipes[i].quantAtleta; j++){
          if(strcmp(equipes[i].listaAtleta[j].cpf, cpf) == 0){
            strcpy(equipes[i].listaAtleta[j].nascimento, atletas[indice].nascimento);
          }
        }
      }
      printf("Data de nascimento do atleta atualizados com sucesso\n");
      break;

    case 7:
      printf("Opcao cancelada\n");
      default:
      printf("Opcao invalida\n");

       *conAtl++;  
  }
}

void registroAtleta(struct atleta atletas[], int *conAtl){
  
  char cpf[15];

  printf("\nDigite o CPF do atleta que deseja acessar: ");
  fgets(cpf, 15, stdin);

  int indice = -1;
  for(int i = 0; i < *conAtl; i++){
    if(strcmp(atletas[i].cpf, cpf) == 0){
      indice = i;
      break;
    }
  }

  if (indice == -1){
    printf("Atleta com CPF %s nao encontrado\n", cpf);
  } else {
     printf("\nDetalhes do atleta:\n");
     printf("Nome: %s", atletas[indice].nome);
     printf("CPF: %s", atletas[indice].cpf);
     printf("Sexo: %s\n", atletas[indice].sexo);
     printf("\nInstituicao de Ensino: %s", atletas[indice].instituicao);
     printf("Data de nascimento: %s", atletas[indice].nascimento);
    }
  }

  void registrosGeralATL(struct atleta *atletas, int *conAtl){

     if (*conAtl == 0) {
        printf("SEM REGISTRO\n");
        return; 
    }
    
    printf("\nRegistros geral de todos os atletas.\n");
    for(int i = 0; i < *conAtl; i++){
      printf("\nAtleta %d:\n", i+1);
      printf("Nome: %s", atletas[i].nome);
      printf("CPF: %s", atletas[i].cpf);
      printf("Sexo: %s\n", atletas[i].sexo);
      printf("\nInstituicao de Ensino: %s", atletas[i].instituicao);
      printf("Data de nascimento: %s", atletas[i].nascimento);

    }
  }
  
void submenuAtlta(struct atleta *atletas, int *conAtl, struct equipe *equipes, int *contequ) {

  struct atleta *novoatletas;
  int numAtletas = 0;
  int escolha;
  
  do {
    printf("\nMenu atleta:\n");
    printf("1. Cadastar\n");
    printf("2. Excluir\n");
    printf("3. Atualizar\n");
    printf("4. Exibir registro\n");
    printf("5. Exibir todos os registros\n");
    printf("6. Sair do menu\n");
    printf("\n");

    printf("Escolha a opcao desejada: ");
    scanf("%d", &escolha);
    getchar();

    switch(escolha) {

      case 1:
        cadastroAtleta(atletas, &*conAtl); 
        break;
      
      case 2:
        excluirAtleta(atletas, &*conAtl, equipes, &*contequ);
        break;
      
      case 3:
        atualizarAtleta(atletas, &*conAtl, equipes, &*contequ);
        break;

      case 4:
        registroAtleta(atletas, &*conAtl);
        break;
      
      case 5:
        registrosGeralATL(atletas, &*conAtl);
        break;
        default:
        printf("Opcao invalida, tente novamente\n");
    }

  } while(escolha != 6);

}  

