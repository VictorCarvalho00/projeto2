#ifndef JOGO_H
#define JOGO_H
#include "estruturas.h"
#include "torneio.h"

void cadastroJogo(struct jogo *jogos, int *contjogo, struct torneio *torneios, int *conttorn);
void excluirJogo(struct jogo *jogos, int *contjogo);
void atualizarJogo(struct jogo *jogos, int *contjogo, struct torneio *torneios, int *conttorn);
void registroJogo(struct jogo jogos[], int *contjogo);
void registrogeralJogo(struct jogo *jogos, int *contjogo);
void submenuJogo(struct jogo *jogos, int *contjogo, struct torneio *torneios, int *conttorn);

#endif // jogo_H