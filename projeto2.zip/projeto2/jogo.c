#include "estruturas.h"
#include "jogo.h"
#include "torneio.h"

void cadastroJogo(struct jogo *jogos, int *contjogo, struct torneio *torneios, int *conttorn)
{
  if(*contjogo > 100){
    printf("Limite de jogos atingidos");
    return;
  }
  
  struct jogo novojogo;

  printf("\nNome do torneio: ");
  fgets(novojogo.nometorneio, 50, stdin);

  int buscarTorneio = 0;
  int indiceTorneio = -1;
  for(int i = 0; i < *conttorn; i++){
    if(strcmp(torneios[i].nomeTorneio, novojogo.nometorneio) == 0){
      buscarTorneio = 1;
      indiceTorneio = i;
      break;
    }
  }

  if(!buscarTorneio){
    printf("Torneio nao encontrado.\n");
    return;
  }

  printf("\nInformações do torneio '%s':\n", novojogo.nometorneio);
  printf("Modalidade do torneio: %s\n", torneios[indiceTorneio].escolhamod);
  printf("Quantidade de equipes inscritas: %d\n", torneios[indiceTorneio].quantequipe);

  printf("Equipes cadastradas no torneio:\n");
  for (int i = 0; i < torneios[indiceTorneio].quantequipe; i++) {
    printf("Sigla da equipe %d: %s\n", i + 1, torneios[indiceTorneio].listaequipe[i].sigla);
    printf("Nome da equipe %d: %s\n", i + 1, torneios[indiceTorneio].listaequipe[i].nome);
  }

  printf("Digite a sigla da primeira equipe: ");
  fgets(novojogo.sigla1, 5, stdin);
   novojogo.sigla1[strcspn(novojogo.sigla1, "\n")] = '\0'; 
  
  int validarS1 = 0;
  for(int i = 0; i < torneios[indiceTorneio].quantequipe; i++){
    if(strcmp(torneios[indiceTorneio].listaequipe[i].sigla,novojogo.sigla1) == 0){
      validarS1 = 1;
      break;
    }
  }

  if(!validarS1){
    printf("Sigla %s nao encontrada.\n", novojogo.sigla1);
    return;
  }

  printf("Digite a sigla da segunda equipe: ");
  fgets(novojogo.sigla2, 5, stdin);
  novojogo.sigla2[strcspn(novojogo.sigla2, "\n")] = '\0'; 
  
  int validarS2 = 0;
  for(int i = 0; i < torneios[indiceTorneio].quantequipe; i++){
    if(strcmp(torneios[indiceTorneio].listaequipe[i].sigla,novojogo.sigla2) == 0){
      validarS2 = 1;
      break;
    }
  }

  if(!validarS2){
    printf("Sigla %s nao encontrada.\n", novojogo.sigla2);
    return;
  }

  printf("Data e horario do jogo, AAAA-MM-DD HH:MM: ");
  fgets(novojogo.dataHora, 20, stdin);
  novojogo.dataHora[strcspn(novojogo.dataHora, "\n")] = '\0';
  
  sprintf(novojogo.identificador, "%s x %s %s", novojogo.sigla1, novojogo.sigla2, novojogo.dataHora);

  printf("Pontuacao do primeiro time: ");
  fgets(novojogo.p1, 10,stdin);
  
  printf("Pontuacao do segundo time: ");
  fgets(novojogo.p2, 10, stdin);

  jogos[*contjogo] = novojogo;
  (*contjogo)++;
  
  printf("Jogo cadastrado com sucesso.\n");
  printf("\nDados do jogo.\n");
  
  for (int i = 0; i < *contjogo; i++){
    jogos[i].sigla1[strcspn(jogos[i].sigla1, "\n")] = '\0';
    jogos[i].sigla2[strcspn(jogos[i].sigla2, "\n")] = '\0';

    printf("Nome do torneio: %s", jogos[i].nometorneio);
    printf("Sigla da primeira equipe: %s\n", jogos[i].sigla1);
    printf("Sigla da segunda equipe: %s\n", jogos[i].sigla2);
    printf("Data e horario do jogo: %s\n", jogos[i].dataHora);
    printf("Identficador do jogo: %s\n", jogos[i].identificador);
    printf("\nPLACAR:\n");
    printf("Pontuacao do primeiro time: %s\n", jogos[i].p1);
    printf("Pontuacao do segundo time: %s\n", jogos[i].p2);
  }
}

void excluirJogo(struct jogo *jogos, int *contjogo) {
    
    char identificador[50];
    int indice = -1;
    
     printf("\nDigite o identficador do jogo: ");
     if(fgets(identificador, sizeof(identificador), stdin) != NULL){
      identificador[strcspn(identificador, "\n")] = '\0';
      } else {
        printf("Erro ao ler o identificador.\n");
        return;
      }

    for (int i = 0; i < *contjogo; i++) {
      if (strcmp(jogos[i].identificador, identificador) == 0) {
        indice = i;
        break;
      }
    }

    if (indice == -1) {
        printf("Jogo com identificador '%s' não encontrado.\n", identificador);
    } else {
      for (int i = indice; i < *contjogo - 1; i++) {
        jogos[i] = jogos[i + 1];
      }
      (*contjogo)--;
      printf("Jogo com identificador '%s' excluído com sucesso.\n", identificador);
   }
}

void atualizarJogo(struct jogo *jogos, int *contjogo, struct torneio *torneios, int *conttorn){

  char identificador[50];

  printf("\nDigite o identificador do jogo que deseja atualizar: ");
  if (fgets(identificador, sizeof(identificador), stdin) != NULL) {
    identificador[strcspn(identificador, "\n")] = '\0'; 
    } else {
      printf("Erro ao ler o identificador.\n");
      return;
    }

  int indice = -1; 
  for(int i = 0; i < *contjogo; i++){
    if(strcmp(jogos[i].identificador, identificador) == 0){
      indice = i;
      break;
    }
  }
  if (indice == -1){
    printf("Identificador invalido");
    return;
  }

  int opcao;

  printf("\nEscolha a opcao desejada:\n");
  printf("1. Todos os dados\n");
  printf("2. Nome do jogo\n");
  printf("3. Sigla da primeira equipe\n");
  printf("4. Sigla da segunda equipe\n");
  printf("5. Data e hora do jogo\n");
  printf("6. Identificador\n");
  printf("7. Pontuacao do primeiro time\n");
  printf("8. Pontuacao do segundo time\n");
  printf("9. Cancelar\n");
  printf("Escolha a opcao desejada: ");
  scanf("%d", &opcao);
  getchar();

  switch(opcao){

    case 1:
      printf("Novo nome do torneio: ");
      fgets(jogos[indice].nometorneio, 50, stdin);
      for (int i = 0; i < *conttorn; i++) {
        if (strcmp(torneios[i].nomeTorneio, identificador) == 0) {
          strcpy(torneios[i].nomeTorneio, jogos[indice].nometorneio);
        }
      }
     
      printf("Nova sigla da primeira equipe: ");
      fgets(jogos[indice].sigla1, 5, stdin);
      
      printf("Nova sigla da segunda equipe: ");
      fgets(jogos[indice].sigla2, 5, stdin);
      
      printf("Nova data e hora do jogo: ");
      fgets(jogos[indice].dataHora, 20, stdin);

      printf("Novo Identificador: ");
      fgets(jogos[indice].identificador, 50, stdin);

      printf("Nova pontuacao do primeiro time: ");
      fgets(jogos[indice].p1, 10, stdin);

      printf("Nova pontuacao do segundo time: ");
      fgets(jogos[indice].p2, 10, stdin);
      break;

    case 2:
      printf("Novo nome do torneio:");
      fgets(jogos[indice].nometorneio, 50, stdin);
      break;

    case 3:
      printf("Nova silga da primeira equipe: ");
      fgets(jogos[indice].sigla1, 5, stdin);
      break;

    case 4:
      printf("Nova silga da segunda equipe: ");
      fgets(jogos[indice].sigla2, 5, stdin);
      break;

    case 5:
      printf("Nova data e hora do jogo: ");
      fgets(jogos[indice].dataHora, 20, stdin);
      break;
    
    case 6:
      printf("Novo Identificador: ");
      fgets(jogos[indice].identificador, 50, stdin);
      break;
      
    case 7:
      printf("Nova pontuacao do primeiro time: ");
      fgets(jogos[indice].p1, 10, stdin);;
      break;

    case 8:
      printf("Nova pontuacao do segundo time: ");
      fgets(jogos[indice].p2, 10, stdin);
      break;

    case 9:
      printf("Operação cancelada\n");
      break;
      default:
      printf("Opção inválida\n");

    (*contjogo)++;
  }
}

void registroJogo(struct jogo jogos[], int *contjogo) {
  
  char identificador[50];

  printf("\nDigite o identificador do jogo que deseja acessar: ");
  if (fgets(identificador, sizeof(identificador), stdin) != NULL) {
    identificador[strcspn(identificador, "\n")] = '\0'; 
    } else {
      printf("Erro ao ler o identificador.\n");
      return;
    }
  
  int indice = -1;
  for(int i = 0; i < *contjogo; i++){
    if(strcmp(jogos[i].identificador, identificador) == 0){
      indice = i;
      break;
    }
  }
  if(indice == -1){
    printf("Jogo com identificador %s nao encontrado\n", identificador);
  } else{
    printf("\nResgistro do jogo\n");
    printf("Nome do torneio: %s", jogos[indice].nometorneio);
    printf("Sigla da primeira equipe: %s\n", jogos[indice].sigla1);
    printf("Sigla da segunda equipe: %s\n", jogos[indice].sigla2);
    printf("Data e hora do Jogo: %s", jogos[indice].dataHora);
    printf("Identificador: %s", jogos[indice].identificador);
    printf("\nPlacar:\n");
    printf("Pontuacao do primeiro time: %s\n", jogos[indice].p1);
    printf("Porntuacao do segundo time: %s\n", jogos[indice].p2);
  }
}

void registrogeralJogo(struct jogo *jogos, int *contjogo) {

   if (*contjogo == 0) {
      printf("SEM REGISTRO\n");
      return; 
    }

  printf("\nRegistro de todos os jogos:\n");
  for(int i = 0; i < *contjogo; i++){
    printf("\nNome do %d torneio: %s", i + 1, jogos[i].nometorneio);
    printf("Sigla da primeira equipe: %s\n", jogos[i].sigla1);
    printf("Sigla da segunda equipe: %s\n", jogos[i].sigla2);
    printf("Data e hora do Jogo: %s\n",jogos[i].dataHora);
    printf("Identificador do jogo: %s", jogos[i].identificador);
    printf("\nPlacar:\n");
    printf("Pontuacao do primeiro time: %s", jogos[i].p1);
    printf("Porntuacao do segundo time: %s", jogos[i].p2);
    
  }
}

void submenuJogo(struct jogo *jogos, int *contjogo, struct torneio *torneios, int *conttorn){

  int escolha;

  do {
    printf("\nMenu jogo:\n");
    printf("1. Cadastar\n");
    printf("2. Excluir\n");
    printf("3. Atualizar\n");
    printf("4. Exibir registro\n");
    printf("5. Exibir todos os registros\n");
    printf("6. Sair do sistema\n");
    printf("\n");

    printf("Escolha a opcao desejada: ");
    scanf("%d", &escolha);
    getchar();

    switch(escolha) {

      case 1:
        cadastroJogo(jogos, &*contjogo, torneios, &*conttorn);
        break;;
      
      case 2:
        excluirJogo(jogos, &*contjogo);
        break;
      
      case 3:
        atualizarJogo(jogos, &*contjogo, torneios, &*conttorn);
        break;

      case 4:
        registroJogo(jogos, &*contjogo);
        break;
      
      case 5:
        registrogeralJogo(jogos, &*contjogo);
        break;
        default:
        printf("Opcao invalida, tente novamente\n");
    }

  } while(escolha != 6);

}   
